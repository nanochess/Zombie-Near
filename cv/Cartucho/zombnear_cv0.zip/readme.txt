Zombie Near, 32K version, Apr/27/2011
(c)Copyright 2011 �scar Toledo Guti�rrez
Contact e-mail: biyubi@gmail.com
Website: http://nanochess.110mb.com/

Pack contains:

   readme.txt    This file
   zombnear.rom  Zombie Near, 32K version for Colecovision
   maps.txt      Maps for beta testing, game can be finished
                 in forty-minutes following these maps.
   sprites.bmp   Main sprites, for manual design if needed.
                 All normal zombies are based on same figure,
                 only with different color.

ATTENTION!

THE FILE ZOMBNEAR.ROM IS EXCLUSIVELY FOR USE OF COLLECTORVISION
FOR PURPOSES OF CARTRIDGE MANUFACTURING

DON'T DISTRIBUTE IT FURTHER!


New features in this version versus MSXdev'10 version:

  o Better graphics for cast' portraits and title screen.
  o The map 3 has two new challenges (zombies' rain and five bosses before final boss).
  o Enhanced music and new theme music for map 2.
  o Various new graphic tiles for maps.
  o A new enemy (zombie crawling) with sound effect.
  o A new fixed enemy (turret) with sound effect.
  o More than seven hundreds of zombies lurking.
  o Logo of Collectorvision.
  o Various small changes and enhancements.

Removed features:

  o Story graphics.
  o Endgame graphics.
  o Spanish language support.

Hardware requirements of the software:

  o A Colecovision console
  o 1K of base RAM
  o 16K of VRAM


Suggested text for license in manual:

  Zombie Near. (c) Copyright 2011 �scar Toledo Guti�rrez

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the author be held liable for any damages
  or loss arising from the use of this software.

  It is prohibited to copy, emulate, clone, lease, sell, modify,
  decompile, disassemble or reverse engineer this software.

  All trademarks are property of their respective owners.

  ---

  The following license applies to Pletter v0.5c decompressor - XL2S Entertainment 2008.
  Copyright (c) 2002-2003 Team Bomba

  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.



Reference of controls for manual's designer:

  Player 1 uses controller 1, buttons 1 and 2 fire.
  Player 2 uses controller 2, buttons 1 and 2 fire.

  Wait while title screen appears to see a small text story.


Score table (for manual design, if needed):

     10 points for bullet hitting enemy.
    100 points for destroying a green zombie.
    100 points for destroying a crawling zombie.
    250 points for destroying a yellow zombie.
    500 points for destroying a black zombie.
    500 points for destroying a white zombie.
   1000 points for rescue of a scientist.
  10000 points for destroying a boss.

  No points for taking life or key, nor for killing a scientist or destroying a life, nor level passing. The turret   cannot be destroyed.


Base credits (add names for manual/cover/box designers and possibly other beta testers)

  ZOMBIE NEAR

  GAME CONCEPT:
  STORY AND CHARACTERS:
  ANIMATION:
  PROGRAMMING:
  GRAPHICS AND LEVEL DESIGN:
  SOUND AND MUSIC:
    �scar Toledo G.

  MUSICAL THEMES:
    Ad�n Toledo G. (also plant drawing)

  BETA TESTERS:
    �scar Toledo G.
    Ad�n Toledo G.

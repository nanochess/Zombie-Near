Zombie Near, Colecovision version (for 128K Megacart), Jul/05/2011
(c)Copyright 2011 �scar Toledo Guti�rrez
Contact e-mail: biyubi@gmail.com
Website: http://nanochess.110mb.com/

Pack contains:

   readme.txt                     This file
   zombnear.rom                   Zombie Near, 128K version for Colecovision
   maps.txt                       Maps for beta testing, game can be finished
                                  in one hour following these maps.
   sprites.bmp                    Main sprites, for manual design if needed.
                                  All normal zombies are based on same figure,
                                  only with different color.

ATTENTION!

THE FILE ZOMBNEAR.ROM IS EXCLUSIVELY FOR USE OF COLLECTORVISION
FOR PURPOSES OF CARTRIDGE MANUFACTURING

DON'T DISTRIBUTE IT FURTHER!


New features in this version versus MSXdev'10 version:

  o Better graphics for cast, title and buildings' image.
  o An extra map with new dialogs and challenges.
  o Enhanced music and new theme music for map 2 and 4.
  o An extra ending for two-players mode when both win.
  o A new title image (now there are three!).
  o Sound when selecting options.
  o Various new graphic tiles for maps.
  o A new enemy (zombie crawling) with sound effect.
  o A new fixed enemy (turret) with sound effect.
  o More than one thousand of zombies lurking.
  o Logo of Collectorvision.
  o A logo for myself
  o Zombies' video (in story, wait at title screen)
  o Digitized PCM sound (at cartridge boot)
  o Various small changes and enhancements.

Removed features:

  o Spanish language support.
  o Screen trembling when bosses jump (needs more RAM)
  o ROM checksum.

New features in comparison with previous non-released 32K Coleco version:

  o Full four-frame animation for bosses.
  o An extra map with new dialogs and challenges.
  o An extra ending for two-players mode when both win.
  o A new title image (now there are three!).
  o Sound when selecting options.
  o More than one thousand of zombies lurking.
  o Enhanced logo of Collectorvision.
  o Zombies' video (in story, wait at title screen)
  o Digitized PCM sound (at cartridge boot)


Hardware requirements of the software:

  o A Colecovision console
  o 1K of base RAM
  o 16K of VRAM


Suggested text for license in manual:

  Zombie Near. (c) Copyright 2011 �scar Toledo Guti�rrez

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the author be held liable for any damages
  or loss arising from the use of this software.

  It is prohibited to copy, emulate, clone, lease, modify,
  decompile, disassemble or reverse engineer this software.

  All trademarks are property of their respective owners.


Reference of controls for manual's designer:

  Player 1 (male) uses controller 1, buttons 1 and 2 fire.
  Player 2 (female) uses controller 2, buttons 1 and 2 fire.

  Both controllers key '*' toggles sound on and off.
  Both controllers key '#' toggles pause on and off.

  Wait while title screen appears to see start story.


Score table (for manual design, if needed):

     10 points for bullet hitting enemy.
    100 points for destroying a green zombie.
    100 points for destroying a crawling zombie.
    250 points for destroying a yellow zombie.
    500 points for destroying a black zombie.
    500 points for destroying a white zombie.
   1000 points for rescue of a scientist.
  10000 points for destroying a boss.

  No points for taking life or key, nor for killing a scientist or destroying a life, nor level passing. The turret cannot be destroyed.


Base credits (add names for manual/cover/box designers and possibly other beta testers)

  ZOMBIE NEAR

  GAME CONCEPT:
  STORY AND CHARACTERS:
  ANIMATION:
  PROGRAMMING:
  GRAPHICS AND LEVEL DESIGN:
  SOUND AND MUSIC:
    �scar Toledo G.

  MUSICAL THEMES:
    Ad�n Toledo G. (also plant drawing)

  BETA TESTERS:
    �scar Toledo G.
    Ad�n Toledo G.

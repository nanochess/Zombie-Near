Zombie Near, 64K version, Apr/11/2011
(c)Copyright 2011 �scar Toledo Guti�rrez
Contact e-mail: biyubi@gmail.com
Website: http://nanochess.110mb.com/

Pack contains:

   readme.txt    This file
   zombnear.rom  Zombie Near, 64K version.

ATTENTION!

THE FILE ZOMBNEAR.ROM IS EXCLUSIVELY FOR USE OF MATRA AND BITWISE
FOR PURPOSES OF CARTRIDGE MANUFACTURING

DON'T DISTRIBUTE IT FURTHER!


New features in this version versus MSXdev'10 version:

  o Better graphics for cast, title and buildings' image.
  o An extra map with new dialogs and challenges.
  o Enhanced music and new theme music for map 2 and 4.
  o Sound when selecting options.
  o Various new graphic tiles for maps.
  o A new enemy (zombie crawling) with sound effect.
  o A new fixed enemy (turret) with sound effect.
  o More than one thousand of zombies lurking.
  o Logo of Matra.
  o Various small changes and enhancements.
  o Now it needs a minimum of 16 KB of RAM.


Hardware requirements of the software:

  o A MSX-compatible computer (MSX, MSX2, MSX2+ or MSX Turbo-R)
  o 16K of base RAM
  o 16K of VRAM


Suggested text for license in manual:

ENGLISH
  This software is provided 'as-is', without any express or implied
  warranty. In no event will the author be held liable for any damages
  or loss arising from the use of this software.

  It is prohibited to copy, emulate, clone, lease, sell, modify,
  decompile, disassemble or reverse engineer this software.

  All trademarks are property of their respective owners.

SPANISH
  Este software es proporcionado 'tal cual', sin ninguna garant�a
  expresa o implicada. En ning�n caso el autor ser� responsable de
  da�os o perdidas que puedan ocurrir por el uso de este software.

  Se prohibe copiar, emular, clonar, alquilar, vender, modificar,
  decompilar, desensamblar e ingenier�a en reversa, de este software.

  Todas las marcas mencionadas pertenecen a sus respectivos propietarios.


Reference of controls for manual's designer:

  One-player mode
    Cursor keys and SPACE to shoot. Also joystick 1, both buttons shoot.

  Two-players mode
    Player 1 - Cursor keys and SPACE to shoot.
    Player 2 - Joystick 1, both buttons shoot,
    Player 2 - WASD-keys combination, Tab for shoot.

  Title screen
    F1 - Change language (English and Spanish available)

  While game runs:
    F1 - Pause, press again to get out from pause
    F2 - Toggle sound/music.

  Wait while title screen appears to see the starting story.


Base credits (add names for manual/cover/box designers and possibly other beta testers)

  ZOMBIE NEAR

  GAME CONCEPT:
  STORY AND CHARACTERS:
  ANIMATION:
  PROGRAMMING:
  GRAPHICS AND LEVEL DESIGN:
  SOUND AND MUSIC:
    �scar Toledo G.

  MUSICAL THEMES:
    Ad�n Toledo G. (also plant drawing)

  BETA TESTERS:
    �scar Toledo G.
    Ad�n Toledo G.
